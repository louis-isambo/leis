import { leistrap } from "../leistrap.js"
import QHeaderCss from "./css/header.css"


leistrap.addCss(QHeaderCss)

export const QHeader = (function(){

    const container  = leistrap.create('div', {className : "qh leis-flex leis-row"})
    return container
})()