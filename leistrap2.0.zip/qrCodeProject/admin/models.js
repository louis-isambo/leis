import { leistrap } from "../leistrap.js"
import {leisModal} from "../../modal/modal.js"

export const QEventModels = (function(){
    
    const container = leisModal("Modèles d'évènements")
    container.setSize("80%", "95vh")

    container.footerCard.content[0].setText("Annuler")
    container.footerCard.content[1].setText("Enregistrer")
    return container
})()