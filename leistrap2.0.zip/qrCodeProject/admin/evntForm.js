import { leistrap } from "../leistrap.js";
import QEFC from "./css/eventForm.css"
import {leisAccordion} from "../../accordion/accordion.js"
import { textBox, leisTextArea } from "../../input/leisInput.js";
import {leisButton} from "../../button/leisButton.js"
import { QEventModels } from "./models.js";


leistrap.addCss(QEFC)
leistrap.addCss(leisButton())

export const QEventForm = (function(){

    const container = leistrap.create("div", {className: "QEC_"})

    //heading
    leistrap.create('h3', {text  : "Créer et partager les code QR pour les  évènements",
        parent : container
    })

    const accordion = leisAccordion(container)
   
    
    //basic information

    const basicInfo = leistrap.create("div", {className : "QAC leis-flex"
    })

    const org = setInput("Organisayeur", "Nom d'hôte")
    
    const title = setInput("Titre", "Nom de l'évènement")

    const summer = setInput("Résumé", "Un bref résumé sur le type de cet évènement ", true)
    
    // date
    const beginningDate = textBox(null, "À partir d'",)
    beginningDate.input.addAttr("type", "date")
    const endingDate = textBox(null, "À")
    endingDate.input.addAttr("type", "date")
 
    leistrap.create("div", {
        parent : basicInfo,
        className : "leis-flex leis-row QDC",
        content : [
            leistrap.create("p", {text : "Lorsque"}),
            leistrap.create("div", {className: "leis-flex leis-row QDFC", 
                content : [beginningDate.container, endingDate.container]
            })
        ]
    })

    // place 

    const place = setInput("Où", "Nom de la place")
    const orgAddress =  setInput("Adresse", "Adresse de l'organisateur") 
    const about  = setInput("À propos", "Les coordonnées de l'organisateur", true)

    accordion.add("information bassique", basicInfo)


    //contact
    const contact = leistrap.create("div", {className : "QAC leis-flex"})

    const email = setInput("Email", "Adresse email de l'organisateur", false, contact )
    email.input.addAttr("type", "email")
    const tel = setInput("Téléphone", "Tél de l'organisateur", false, contact )
    tel.input.addAttr("type", "telephone")
    accordion.add("Contact", contact)

    //models button

    const modelBtn = leistrap.create("button", {
        className : "leis-btn leis-btn-primary",
        type : "button",
        text : "Choisir un modèle",
        onclick : function(){QEventModels.show()}
    })

    leistrap.create("div", {
        className : "leis-flex",
        content : [modelBtn],
        parent : container,
        style : {marginTop : "1rem"}
    })
    function setInput(lbl, placeHolder, textArea, parent){
        const elem = textArea ? leisTextArea(parent || basicInfo, lbl )  : textBox(parent || basicInfo, lbl)
        elem.input.addAttr("placeholder", placeHolder).setStyleSheet({width : "60%", padding : "8px 8px"})
        elem.container.setStyleSheet({flexDirection : "row", justifyContent: "space-between"})

        elem.container.setClassName("QIC")
        if(textArea){
            elem.input.setStyleSheet({resize : "none", height : "120px"})
        }
        return elem
    
    }


    return container
})()