import { leistrap } from "../leistrap.js";
import QContentCss from "./css/content.css"
import {leisTab} from "../../tabPage/tabPage.js"
import { QEventForm } from "./evntForm.js";

leistrap.addCss(QContentCss)

export const QContent = (function(){

    const container = leistrap.create("div", {className: "Qc"})

    const contentCard = leistrap.create("div", {
        parent : container,
        className : "Qcc",
        
    })

    const tab  = leisTab({
        btnParent : contentCard,
        contentParent : contentCard,
        createButton : true
    })
    tab.buttonsContainer.setClassName("QTBC")

    
    //add event page
    setTabBtn("Evànements", "event", QEventForm)

    //numeric menu
    setTabBtn('Menu numérique', "numeric-menu", leistrap.create("div", {text : leistrap.lorem}))

    setTabBtn('Carte de visite', "visit-card", leistrap.create("div", {text : leistrap.lorem}))
    setTabBtn('Billet d\'évènement', "event-bill", leistrap.create("div", {text : leistrap.lorem}))
    

    function setTabBtn(lbl , name, content){
        return   tab.define( name, content, {
            buttonText : lbl,
            createButton : true
        }).setClassName("QTB")

    }
    return container
})()