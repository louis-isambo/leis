import {leistrap} from "../leistrap/leistrap.js"


(function(){
    globalThis.leistrap = leistrap
})()

export {leistrap}