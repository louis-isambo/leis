import { leistrap } from "../leistrap/leistrap.js";
import { isEmpty, rangeList } from "../obj/index.js";
import { setPopPosition } from "../popup/popup.js";
import elementCss from "./css/element.css"
import { leisTab } from "../tabPage/tabPage.js"
import { textBox } from "../input/leisInput.js"
import { btnElements } from "./elements/btn.js";
import { ContainersElements } from "./elements/contaner.js";


export const leisUiElements = (function () {
    leistrap.addCss(elementCss)

    const container = leistrap.create("div", {
        parent: "leistrapUi",
        className: "leis-dropdown-content elements-cd",
        onclick: (e) => e.stopPropagation(),


    })

    const searchBar = textBox(container, null)
    // elements tab


    const elementTabMap = [
        { name: "Bouton", elem: leistrap.create("div", { content: btnElements() }) },
        { name: "Containeur", elem: leistrap.create("div", { content: ContainersElements() }) },
        { name: "Champs de text", elem: leistrap.create("div", { text: "champs text" }) },
        { name: "Titres", elem: leistrap.create("div", { text: "Titres" }) },
        { name: "Liste déroulante", elem: leistrap.create("div", { text: leistrap.MLorem(100) }) },
        { name: "Audio", elem: leistrap.create("div", { text: leistrap.MLorem(100) }) },
        { name: "Vidéo", elem: leistrap.create("div", { text: leistrap.MLorem(100) }) }
    ]
    const tab = leisTab({
        btnParent: container,
        contentParent: container
    })

    tab.buttonsContainer.setClassName("element-tab-btn")

    // add all elements tab to the container
    elementTabMap.forEach(item => {
        tab.define(item.name, item.elem,
            { buttonText: item.name, createButton: true }).setClassName("element-tab-item")
        item.elem.setClassName('element-tab-content leis-flex')
    })

    // hide the container when window is clicked
    leistrap.hideWhenWinClick(() => container.removeClassName("show"))
    return leistrap.create("div", {
        text: "elements",
        className: 'toolbar-item',
        onclick: function (e) {
            e.stopPropagation()
            container.setClassName("show")
            setPopPosition("absolute", {
                container: this._conf,
                popUp: container._conf,
                side: ["top", "right", "left"]
            })

        }
    }).addAttr("tabindex", "0")
})()