import { leistrap } from "../../leistrap/leistrap.js";
import { leisButton } from "../../button/leisButton.js"
import { leisResizable } from "../../mouseEvent/index.js";




export function btnElements() {
    leistrap.addCss(leisButton())

    // BUTTON COLOR TYPES
    const btnTypes = [
        'primary',
        "secondary",
        "warning",
        "light",
        'danger',
        "dark",
        "info",
        "success"
    ]

    // buttons with background
    const btnWithBg = btnTypes.map(function (btn) {
        return leistrap.create('button', {
            text: btn,
            className: `leis-btn leis-btn-${btn} btn-element`,
            onclick: function () {
                const newBtn = leistrap.create("button", {
                    type: 'button', text: btn,
                    className: `leis-btn leis-btn-${btn}`,
                    onfocus: setProp
                })
                leisResizable(newBtn, 'leistrapUi-content')
            }
        })
    })

    // buttons with outlines
    const btnOutline = btnTypes.map(function (btn) {
        return leistrap.create('button', {
            text: btn,
            className: `leis-btn leis-outline-btn-${btn} btn-element`,
            onclick: function () {
                const newBtn = leistrap.create("button", {
                    type: 'button', text: btn,
                    className: `leis-btn leis-outline-btn-${btn}`,
                    onfocus: setProp
                })
                leisResizable(newBtn, 'leistrapUi-content')
            },

        })
    })

    // display the button properties to the properties nar
    // liston to the focus in event
    /**
     * @this {leistrap.Leistrap<HTMLButtonElement>}
     */
    function setProp() {
        const props = {
            color: "red"
        }
        leistrap.event.invoke('propBar', null, this, props)

    }

    return [
        leistrap.create("button",
            {
                type: "button", text: "Bouton leistrap", className: "leis-btn btn-element",
                onclick: function () {
                    const newBtn = leistrap.create("button", {
                        type: 'button', text: "Bouton",
                        className: `leis-btn`,
                        onfocus: setProp
                    })
                    leisResizable(newBtn, 'leistrapUi-content')
                },

            }),
        leistrap.create("h3", { text: "Boutons avec arrière plan", className: 'title' }),
        leistrap.create("div", { content: btnWithBg, className: "leis-col-4" }),
        leistrap.create("h3", { text: "Boutons avec contoures", className: 'title' }),
        leistrap.create("div", { content: btnOutline }),

    ]
}