import { leistrap } from "../../leistrap/leistrap.js";
import { leisResizable } from "../../mouseEvent/index.js";


function ContainersElements() {

    function setContainer() {
        const elem = leistrap.create("div", {
            style: {
                width: "100px",
                height: "100px",
                backgroundColor: "grey"
            }
        })
        return elem
    }

    return [
        setContainer().addEvent('click',
            () => leisResizable(setContainer(), "leistrapUi-content"))
    ]
}

export { ContainersElements }