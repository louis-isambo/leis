import { autoComplete } from "../../autocomplete/autocomplete.js";
import { btnRadio, textBox } from "../../input/leisInput.js";
import { leistrap } from "../../leistrap/leistrap.js";
import { generateId, has, loopObject } from "../../obj/index.js";
import { DropUp } from "../../popup/index.js";
import {ColorProp} from "./color.js"
import { CssUnit } from "./unit.js";

const BorderProp = (function(){

    const prop = {
        bd : null,
        bdValue : {
            color : 'red',
            width : "1px",
            style : "solid"
        },
        bdRadius  : {
            radius : "0",
            left : "0",
            right : "0",
        
        }
    }
    
    const borderCard = DropUp()
    const sizeUnitChooser = CssUnit()
    sizeUnitChooser.useShow()

    borderCard.once("click", function(){
        sizeUnitChooser.hide()
        ColorProp.hide()
    })

    borderCard.pop.setStyleSheet({
        width : "300px",
        height : "400px"
    })
    
    leistrap.create("h3", {
        text: "Spacing",
        parent: borderCard.pop,
        className: 'pop-title'
    })

    const left = leistrap.create('div', {
        style : {
            width : "40%"
        }
    })
    const right = leistrap.create('div', {
        style : {
            borderLeft : "var(--leis-border)",
            paddingLeft : "10px",
            width : "60%",
        }
    })

    const bottom = leistrap.create("div",{
        style : {
            paddingTop: "1rem",
            borderTop : "var(--leis-border)"
        }
    })

    leistrap.create("div", {
        className : "leis-flex leis-row",
        content : [left, right],
        parent : borderCard.pop
    }).content.forEach(function(item){
        item.setStyleSheet({
            height : "130px",
            flexDirection : "row"
        })
    })
    borderCard.pop.add(bottom)

    const borderValues = ["Border", "Top", "Left", "Right", "Bottom"]
    let id  = generateId(2, 3)

    borderValues.forEach(function(item, index){
        const input = btnRadio(left, item, active)
        input.input.addAttr('name', id)
        input.input.value = item == "Border" ? "border" : "border"+item

        input.container.setStyleSheet({
            flexDirection : "row-reverse"
        })
    })

    const borderStyle = ['solid', "dashed","dotted", "double", "groove", "hidden", "inherit",
        "initial", "inset", "none", "outset", "ridge", "unset"
    ]

    const bdW = textBox(right, "Width")
    const bdS = textBox(right, "Style")
    const bdC = textBox(right, "Color") 
    const radius = textBox(bottom, "Radius")
    const radiusLeft = textBox(bottom, "Left")
    const radiusRight = textBox(bottom, "Right")
    
    autoComplete(bdS.container, bdS.input, borderStyle,
        function(value){prop.bdValue.style = value; getBorder()}
    ).setClassName("aut-fw")
    bdW.input.addEvent("input", function(){
        prop.bdValue.width =  this._conf.value+ (this.unit || "px")
        getBorder()
       
    })

    bdW.input.addAttr('type', "number")
    bdC.input.setStyleSheet({background: "red"})
    const radius_ = [radius, radiusLeft, radiusRight]

    radius_.forEach(function(item, index){
        item.container.setStyleSheet({
            flexDirection : "row"
        })
        item.input.setStyleSheet({
            width : "60%"
        }).addAttr("type", "number")
        item.label.setStyleSheet({
            fontSize : "14px",
            minWidth : "40px"
        })

        sizeUnitChooser.btn(item.container, item.input, function(unit){
            item.input.unit = unit 
            getRadius(item.input._conf.value+unit, index)
        }).setStyleSheet({
            fontSize : '13px'
        })

        item.input.addEvent("input", function(){
            if(prop.bd) getRadius(this._conf.value+this.unit || 'px' , index)
        })
    })

    sizeUnitChooser.btn(bdW.container, bdW.input, function(unit){
        prop.bdValue.width = bdW.input._conf.value + unit
        bdW.input.unit = unit
        getBorder()
        
    }).setStyleSheet({
        fontSize : "14px",
        position : "absolute",
        right : "-13px",
        top : "-2px"
    })
    const inputs = [bdS, bdW, bdC]

    inputs.forEach(function(item){
        item.container.setStyleSheet({
            flexDirection : "row"
        })
        item.input.setStyleSheet({
            width : "50%"
        })
        item.label.setStyleSheet({
            fontSize : "14px",
            minWidth : "40px"
        })

    })

    ColorProp.setBtn(bdC.input)
    bdC.input.popInstance = true
    
    bdC.input.addEvent("click", function(){
        ColorProp.prevAction = ColorProp.action
        ColorProp.action = function(value){
            bdC.input.setStyleSheet({background: value})
            prop.bdValue.color = value
            getBorder()
        }
    })


    /**
     * @this {leistrap.Leistrap<HTMLElement>}
     */
    function active(){
       prop.bd = this.value
       const inputs = [radiusLeft, radiusRight, radius]
        
       inputs.forEach(function(item){
        item.input.removeAttr("disabled")
        item.input.state.readonly = false
       })


       if(has(this.value.toLowerCase(), ["bordertop", "borderbottom"])){
        radius.input.addAttr("disabled", "true").state.readonly = true
       }
      
       if(has(this.value.toLowerCase(), ["border"])){
        radiusLeft.input.addAttr("disabled", "true").state.readonly = true
        radiusRight.input.addAttr("disabled", "true").state.readonly = true
       }
    
       if(has(this.value.toLowerCase(), ["borderleft", "borderright"])){
            inputs.forEach(function(item){
                item.input.addAttr("disabled", "true")
                item.input.state.readonly = true
            })
       }
      

       if(prop.bdRadius){
        getRadius()
       }
    }

    function getStyle(prop_, value){
        const style = {}
        style[prop_] = value 
        if(borderCard.action) borderCard.action(style)
    }

    function getRadius(value,  index){
        getStyle(prop.bd+['Radius', "LeftRadius", "RightRadius"] [index], value )
    }
    function getBorder(){
        if(prop.bd){
                       
            getStyle(prop.bd, ` ${prop.bdValue.width} ${prop.bdValue.style} ${prop.bdValue.color}`
            )
        }
    }

    return borderCard
})()


export {BorderProp}