import {leistrap} from "../../leistrap/leistrap.js"
import styleCss from "../css/font.css"
import {DropUp} from "../../popup/index.js"
import {leisTab} from "../../tabPage/tabPage.js"
import {textBox} from "../../input/leisInput.js"
import { choice, isEmpty, loopObject } from "../../obj/index.js"
const FontProp = (function(){
  
leistrap.addCss(styleCss)
const fontStyle = leistrap.addCss("", true)
let counter = 0
let fontListItems, parentElement;
let stopValue =  10
let loadTime = 50

const webSafeFonts = {
  "Sans-Serif" : [
    "Arial",
    "Verdana",
    "Helvetica",
    "Trebuchet MS",
    "Tahoma",
  ],
  "Serif" : [
    
    "Times New Roman",
    "Georgia",
    "Garamond",

  ],
  "Monospace" : [
     
    "Courier New",
    "Lucida Console",
    "Consolas",
    "Monaco",
    "Comic Sans MS",
  ],

  "Cursive" : [
    "Impact",
  ],
  "System Fonts" : [
    "Segoe UI",
    "Calibri",
    "San Francisco",
    "Lucida Grande",
    "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;"
  ]
};

const downloadedFonts = webSafeFonts

  async function loadFont(parent){
    const key = "AIzaSyDIlP0xLUUPNI4TFGmMuiPGZHeMdkoH3kI"
    const capability = "&capability=WOFF2"
    fetch("https://www.googleapis.com/webfonts/v1/webfonts?key="+key+capability).then(  async function(data){

      const fontList =  await  data.json()
      fontListItems = fontList.items
      const itemsLength = fontListItems.length
      parentElement = parent
      startLoading()
    })

  }
  
  function setMark(elem){
    if(fontCard.selected)fontCard.selected.removeClassName("selected")
      elem.setClassName("selected")
      fontCard.selected = elem

  }
  /**
   * 
   * @param {Array<{
   * kind : string,
   * family: string,
   * menu: string,
   * variants : Array<string>,
   * subsets : Array<string>,
   * version : string,
   * lastModified : string,
   * files : {},
   * category : string,
   * }>} fontList
   * @param {leistrap.Leistrap<HTMLElement>} parentElement 
   */
  function getFonts(fontList, parentElement){
    
    if(counter <=  stopValue){
      let fontObject = fontList[counter]
      let variantsList =  Object.keys(fontObject.files)
      let variantsCounter = 0

      let fontFamilyParent;
      let  fontFa = leistrap.create("div", {className : "fontFamily-cd"})

      let caption = leistrap.create("div", {
        className : "caption cd",
        text : fontObject.family,
        style : {fontFamily : fontObject.family+"regular"},
      })
      let container = leistrap.create("div", { 
        content : [caption, fontFa],
        parent : parentElement,
        className : "font-container",
        onclick : function(){
          fontFa.toggleClassName("clicked") 
          caption.toggleClassName("clicked")
        }
      })

    
      
      if(variantsList.length == 1) {
        caption.removeClassName("cd")
        fontFamilyParent = container
        
      }
      else{fontFamilyParent = fontFa}

      if(variantsCounter <= variantsList.length -1){
        getFontVariants(variantsList[variantsCounter], fontObject, fontFamilyParent,countVariant)
      }

      function countVariant(){
        if(variantsCounter+1 === variantsList.length){
          // all variants are already loaded let continue getting other font
         if(counter+ 1 == stopValue) console.log("all font  loaded");
         else {
          counter++
          startLoading()
         }
        }
        else
        if(variantsCounter < variantsList.length - 1 ){
          variantsCounter++
          getFontVariants(variantsList[variantsCounter], fontObject, fontFamilyParent,countVariant)
        }

      }
    }
  }

  /**
   * 
   * @param {{
  * kind : string,
  * family: string,
  * menu: string,
  * variants : Array<string>,
  * subsets : Array<string>,
  * version : string,
  * lastModified : string,
  * files : {},
  * category : string,
  * }} fontObject
  * @param {leistrap.Leistrap<HTMLElement>} parentElement
  * @param {string} variantId  
  */
  function getFontVariants(variantId, fontObject, parentElement, callback){

    let variant = variantId
      let fontName = fontObject.family.replace(/ /g, "")+variant.replace(/ /g, "")
      fetch(fontObject.files[variant]).then( async function(data){

        const fontBlob =  await data.blob()

       // load all font variant blob object
       const reader = new FileReader()
       reader.onload = function(e){
         
        let  fontLoad =  ` @font-face {font-family:${fontName};src: url(${e.target.result}); }`
         fontStyle._conf.innerText += fontLoad
         leistrap.event.invoke("googleFontLoading", null, fontLoad)
       
        if(Object.keys(fontObject.files).length == 1)
          parentElement.addEvent("click", function(){
          const font =  {
              type : "googleFonts",
              fontFamily : fontObject.family,
              fontName, fontBlob, fontUrl:fontObject.files[variant]
            }
          
          if(fontCard.action) fontCard.action(font)
          setMark(parentElement)
          }) 
        
        else{
          leistrap.create("p", {
            text : fontObject.family + " " + variant,
            parent : parentElement,
            style : {fontFamily : fontName},
            className : "font-item",
            onclick : function(e){
              e.stopPropagation()
              const font = {
                fontFamily : fontObject.family,
                type : "googleFonts",
                fontName, fontBlob, fontUrl:fontObject.files[variant]
              }; 
              if(fontCard.action) fontCard.action(font)
             setMark(this)
            }
        })

        }

        }
       reader.readAsDataURL(fontBlob)
        callback()
        
      }).catch(function(err){
        console.log('error', err.type);
        
      })
    
  }

  function startLoading(){
    setTimeout(function(){
      getFonts(fontListItems, parentElement)
    }, loadTime)
  }


  function loadWebSafeFonts(parent){
    loopObject(webSafeFonts, function(value, key){

      let  fontFa = leistrap.create("div", {className : "fontFamily-cd"})

      let caption = leistrap.create("div", {
        className : "caption cd",
        text : key,
        style : {fontFamily : choice(value)},
      })
      

      leistrap.create("div", { 
        content : [caption, fontFa],
        parent : parent,
        className : "font-container",
        onclick : function(){
          fontFa.toggleClassName("clicked") 
          caption.toggleClassName("clicked")
        }
      })._conf.click()

      value.forEach(function(item){
        leistrap.create("p", {
          text :  item,
          parent : fontFa,
          style : {fontFamily : item},
          className : "font-item",
          onclick : function(e){
            e.stopPropagation()
           const font = {
            type : "webSafeFont",
            fontName : item
           };
           if(fontCard.action) fontCard.action(font)
          setMark(this)
          }
      })

      })
    })
  }

  function loadDownloadedFonts(parent){
    loopObject(downloadedFonts, function(value, key){

      let  fontFa = leistrap.create("div", {className : "fontFamily-cd"})
 
      
      let caption = leistrap.create("div", {
        className :  `caption cd`,
        text : key,
        style : {fontFamily : choice(value)},
      })
      
      const container = leistrap.create("div", { 
        content : [caption, fontFa],
        parent : parent,
        className : "font-container",
        onclick : function(){
          fontFa.toggleClassName("clicked") 
          caption.toggleClassName("clicked")
        }
      })

      if(value.length  == 1){
        caption.setText(value[0])
        caption.removeClassName("cd")
        caption.setStyleSheet({fontFamily : value[0]})
        caption.addEvent('click', function(){
          const font  = { 
            type : "downloadedFonts",
            fontUrl : null,
            fontPath : null,
            fontName : value[0]
           };
          if(fontCard.action) fontCard.action(font)
          setMark(this)
        })
      }

      else{
        container._conf.click()
        value.forEach(function(item){
          leistrap.create("p", {
            text :  item,
            parent : fontFa,
            style : {fontFamily : item},
            className : "font-item",
            onclick : function(e){
              e.stopPropagation()
             const font = { 
              type : "downloadedFonts",
              fontUrl : null,
              fontPath : null,
              fontName : item
             };
            if(fontCard.action) fontCard.action(font)
           setMark(this)
            }
        })
  
        })
      }
    })
    
  }
  //typography component declaration

  const fontCard = DropUp()
  fontCard.pop.setStyleSheet({
    width  : "300px",
    height : "500px"
  })

  leistrap.create("h3", {text : "Font family", parent: fontCard.pop,className : "pop-title"})


  const Header = leistrap.create("div", {className: "pop-header font-header", parent : fontCard.pop})
  const SearchBar = textBox(Header)
  SearchBar.input.addAttr("placeholder", "Search here...")
  const body = leistrap.create("div", {parent : fontCard.pop, className : "pop-body font-body"})
 

  // font tab
  const tab = leisTab({
    btnParent : Header,
    contentParent : body
  })
  
  const webSafeTabCnt = leistrap.create("div")

  const downloadedFontCnt = leistrap.create("div")

  const googleFont = leistrap.create("div")

  tab.define('webSafeFont', webSafeTabCnt, {
    buttonText : "Web safe",
    createButton : true
  } ).setClassName("tab-btn-font")

  tab.invoke("webSafeFont")
  
  tab.define('downloadedFonts', downloadedFontCnt, {
    buttonText : "Downloaded",
    createButton : true
  } ).setClassName("tab-btn-font")

  tab.define('googleFonts', googleFont, {
    buttonText : "Search",
    createButton : true
  } ).setClassName("tab-btn-font")

  setTimeout(loadWebSafeFonts, loadTime, webSafeTabCnt)
  setTimeout(loadDownloadedFonts, loadTime, downloadedFontCnt)
 loadFont(googleFont)


 
  return fontCard
})()

export {FontProp}