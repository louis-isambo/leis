import { DropUp } from "../../popup/index.js";
import {leistrap} from "../../leistrap/leistrap.js"
import { has, isEmpty } from "../../obj/index.js";
import { leisTextArea, textBox } from "../../input/leisInput.js";

export function CssUnit(){

    // size unit
    let sizeUnit = ["px", "%", "em", "rem", "ch", "vw", "vh", "svw", "svh"]
    const defaultUnit = ["auto", "inherit", "initial", "unset", "calc()"]
    sizeUnit = sizeUnit.concat(defaultUnit)

    const calcDrop = DropUp()

    leistrap.create("h4", {
        text: "calc",
        parent: calcDrop.pop,
        className: 'pop-title',
        style : {margin : "0"}
    })
    calcDrop.pop.setStyleSheet({
        width : "250px",
        height : "150px",
        overflow : "hidden",
      
    })

 
    const calcInput = leisTextArea(calcDrop.pop)
    calcInput.input.setClassName("calcInput")

    calcInput.input.addEvent("input", function(){

        if(sizeUnitChooser.input){
            sizeUnitChooser.input._conf.value = ""
            sizeUnitChooser.input.addAttr("disabled", "true")
           }
        const values = this._conf.value.replace(/\n/g, " ")
        .replace(/\+/g, " + ").replace(/\-/g, " - ")
        .replace(/\*/g, " * ").replace(/\//g, " / ")
        const result = `calc(${values})`
        if(!leistrap.currentElement.unitValue) 
            leistrap.currentElement.unitValue = {}
        leistrap.currentElement.unitValue[sizeUnitChooser.btn.key] = values
        if (sizeUnitChooser.action) sizeUnitChooser.action(result)

    })
    //color unit chooser
    const sizeUnitChooser = DropUp()
    sizeUnitChooser.pop.setStyleSheet({
        width: '100px',
        height: (sizeUnit.length + (sizeUnit.length * 28)).toString() + "px"
   
    }).addElements(...sizeUnit.map(item => {
       const elem =  leistrap.create('div', {
            text: item.toUpperCase(),
            className: "overflow-item",
            onclick: function () {
                sizeUnitChooser.pop.content.forEach(item => item.removeClassName("selected"))
                this.setClassName("selected")
                if (sizeUnitChooser.action && item != "calc()") sizeUnitChooser.action(item.toLowerCase())
               },
            style : {fontSize : "14px"}
        }) 
        
        if(item == "calc()"){
            calcDrop.setBtn(elem)
           
            elem.addEvent("click", function(){ 
                elem.setClassName("selected")
                calcInput.input._conf.focus()
               calcInput.input._conf.value = leistrap.currentElement.unitValue[sizeUnitChooser.btn.key] || ""
               if(leistrap.currentElement.unitValue[sizeUnitChooser.btn.key]){
                 sizeUnitChooser.input._conf.value = ""
                sizeUnitChooser.action(`calc(${leistrap.currentElement.unitValue[sizeUnitChooser.btn.key]})`)
               }
               
                
            })
        }
        return elem
    }) ).setStyleSheet({ padding: "0" })
   
    
   function useShow(){
     // initialization of the siz unit when the component is opened
     sizeUnitChooser.once("show", function () {

        sizeUnitChooser.unit = sizeUnitChooser.unit || "auto"
        if(sizeUnitChooser.unit.startsWith("calc")){
             sizeUnitChooser.unit = "calc()"
             
        }
           

        sizeUnitChooser.pop.content.forEach(item => {
            item.removeClassName("selected")
            if (item.getText().toUpperCase() == sizeUnitChooser.unit.toUpperCase()){
                item.setClassName("selected")
                item._conf.click()
            }
        })
    })
   }

   sizeUnitChooser.once("hide", function(){
    calcDrop.hide()
   })

   sizeUnitChooser.once("click", function(){
    calcDrop.hide()
   })

   function setUnit(unit, input, btn){
        if(has(unit, sizeUnit)){
            sizeUnitChooser.pop.content.forEach(item => {
                if(item.getText().toLocaleLowerCase() === unit.toLocaleLowerCase()){
                    item.setText(unit.toUpperCase())
                  if(!has(unit, defaultUnit)) input.removeAttr("disabled")
                if(btn) {
                    btn.setText(unit)
                    btn.selected = item
                }
                }
                
            })
        }
   }
   sizeUnitChooser.useShow = useShow
   sizeUnitChooser.setUnit = setUnit
   sizeUnitChooser.defaultUnit = defaultUnit


   sizeUnitChooser.btn = function(parent, input, action){
   const unitBtn =  leistrap.create("button", {
        type: "button",
        text: "auto",
        className: 'unitBtn',
        parent,
        onclick: function () {
            sizeUnitChooser.pop.state.visible = false
            sizeUnitChooser.unit = this.getText()
            sizeUnitChooser.btn = this
            sizeUnitChooser.input = input
            calcDrop.hide()

            sizeUnitChooser.action = (unit) => {
                this.setText(unit)
                this.unit = unit
                
                // disable the input when he unit is set to auto
                if (has(unit, defaultUnit)) {
                    input.addAttr("disabled", "true")
                    input._conf.value = ""
                    sizeUnitChooser.hide()
                }
                else { 
                    if(!input.state.readonly)input.removeAttr("disabled")
                   
                }      
                if(action) action(unit)
                
            }
        }
    })
    sizeUnitChooser.setBtn(unitBtn)
    return unitBtn
   }

   
   return sizeUnitChooser
   
} 