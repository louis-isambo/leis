import { leistrap } from "../../leistrap/leistrap.js";
import { DropUp } from "../../popup/index.js";
import { textBox } from "../../input/leisInput.js";
import { CssUnit } from "./unit.js";
import { leisTab } from "../../tabPage/tabPage.js";

const SpacingProp = (function(){



    const spacingCard = DropUp()
    spacingCard.pop.setStyleSheet({
        width  : "340px",
        height : "250"
      })
    
    spacingCard.once('click', function(){
        sizeUnitChooser.hide()
    })

    leistrap.create("h3", {
        text: "Spacing",
        parent: spacingCard.pop,
        className: 'pop-title',
     
    })

  
    const Header = leistrap.create("div", {className: "pop-header font-header", parent : spacingCard.pop})
    const body = leistrap.create("div", {parent : spacingCard.pop, className : "pop-body font-body"})


      // font tab
    const tab = leisTab({
        btnParent : Header,
        contentParent : body
    
    })

    const sizeUnitChooser = CssUnit()
    sizeUnitChooser.useShow()

    function setProp(prop){
          // edges
    const edges = [prop, "Top", "Left", "Right", "Bottom"]
    
        //margin
        const container = leistrap.create("div",{
            style : {
                marginTop : "1rem",
                fontFamily : "inherit"
            },
            content : edges.map(function(item, index){
            if(index == 0){
             return setInput(null, prop, prop.toLowerCase()).container
            }
            else {return setInput(null, prop+"-"+item, prop.toLowerCase()+item).container}
        })
        })
    
        tab.define(prop, container, {
            buttonText : prop,
            createButton : true
        } ).setClassName("tab-btn-font")


    }

    function setInput(parent, lbl, prop){

        const input = textBox(parent, lbl)
        

        /**
        * @type {leistrap.Leistrap<HTMLButtonElement>}
        */
        const btnUnit = sizeUnitChooser.btn(input.container, input.input,function(unit){
        getStyle(prop, input.input._conf.value+unit)
        
        } )
        btnUnit.setClassName("fs-b")
        btnUnit.setStyleSheet({right : "5px"})
        input.input.addAttr("type", "number")

        input.input.setStyleSheet({width : "50%"})
        input.container.setStyleSheet({flexDirection : "row"})
        input.label.setStyleSheet({
                display: "inline-block",
                minWidth : "90px",
                fontSize : "13px",
                fontFamily : "inherit"
        })
        input.input.addEvent("input", function () {getStyle(prop, this._conf.value+btnUnit.unit)})
        
        return input
    }
    

    function getStyle(prop , value){
        let style = {}
        style[prop]  = value
        if(spacingCard.action) spacingCard.action({style})
    }

    setProp("Margin")
    setProp("Padding")
    tab.invoke('Margin')
    return spacingCard
})()

export {SpacingProp}