import { leistrap } from "../leistrap/leistrap.js";
import { rangeList } from "../obj/index.js";
import { configProp } from "./confugProp.js";
import { Root } from "./root.js";



function APP(){

    Root.whenReady = function(body){
        let workSpaceBody = leistrap.create("div")
        workSpaceBody._conf = body
        body.currentElement = workSpaceBody
    
        leistrap.currentElement = workSpaceBody
        workSpaceBody.styleData = {}

        // add a style tag for loading google font
        let googleFont = leistrap.create("style", {parent : workSpaceBody})
        leistrap.event.handle("googleFontLoading", function(e, value){
            googleFont._conf.innerText += value
        })
        
        leistrap.create("h1", {parent: workSpaceBody, text : "This is a title"})
        leistrap.create("p", {parent: workSpaceBody, text : leistrap.MLorem(1)})
        
        rangeList(8).forEach(function(item){
            leistrap.create("button", {type: "button", text: "button "+item.toString(), parent: workSpaceBody})
        })
        leistrap.create("p", {parent: workSpaceBody, text : leistrap.MLorem(1)})

        leistrap.create("img", {parent : workSpaceBody, src : "https://static01.nyt.com/images/2023/07/27/multimedia/27dc-trump-01-qwbh/27dc-trump-01-qwbh-videoSixteenByNine3000.jpg"})
        leistrap.create("p", {parent: workSpaceBody, text : leistrap.MLorem(10)})
        //get all element by a click
        Root.workSpace._conf.contentDocument.addEventListener("click", function(e){
            leistrap.currentElement = e.target.currentElement

            //call styleEmitter to handle elementChanged event
            configProp.StyleEmitter.invoke("elementChanged", null, leistrap.currentElement)
            leistrap.event.invoke("hidepopup")
            
            // close colorPicker

            leistrap.event.invoke("colorPicker:close")
        })
    }
}

export {APP}