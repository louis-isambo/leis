import { leistrap } from "../leistrap/leistrap.js";
import { Root } from "./root.js";
import {leisCollapse} from "../collpse/collapse.js"
import { textBox } from "../input/leisInput.js";
import { configProp } from "./confugProp.js";
import {SizeProp} from "./props/size.js"
import { ColorProp } from "./props/color.js";
import {typographyProp} from "./props/typography.js"
import { StyleEmitter } from "./eventCompStyle.js";
import {SpacingProp} from "./props/spacing.js"
import  {BorderProp} from "./props/border.js"


const StyleView = (function(){    

    const container = leistrap.create("div", {parent : Root.propSide})
    const sizeValues =  ["width", "min-width", "max-width", "height", "min-height", "max-height"]

    // display size props
    leisCollapse(container,"Size", sizeValues
        .map(function(item){
            const elem = setInput(item)

            elem.input.addEvent("click", function(){configProp.propEmitter.invoke("size")})
            SizeProp.setBtn(elem.input)

            configProp.StyleEmitter.handle(item.replace('-', ""), function(event, value){
                elem.input._conf.value = value
            })
            
            return elem.container
    }) )
    
    //color
    leisCollapse(container, "Colors", ["color", "bg-color"].map(function(item, index){
        const elem = setInput(item)
        ColorProp.setBtn(elem.input)

        if(index == 0){
            elem.input.addEvent("click", function(){
                configProp.propEmitter.invoke('color')
                leistrap.event.invoke("clr-previous:set", null, leistrap.currentElement.styleData.color)
            })
            
            leistrap.event.handle("colors:color", function(e){elem.input._conf.click()})
        }
        else{
            item = "backgroundColor"
            elem.input.addEvent("click", function(){
                configProp.propEmitter.invoke(item)
                
                leistrap.event.invoke("clr-previous:set", null, leistrap.currentElement.styleData.backgroundcolor)
            })
            leistrap.event.handle("colors:bg", function(e){elem.input._conf.click()})
        }

        configProp.StyleEmitter.handle(item.toLocaleLowerCase(), function(event, value){
            elem.input.setStyleSheet({backgroundColor: value})
        })
        return elem.container
    }))

    //typography
    const typo = ["font-size", "font-weight", "font-family",  ]
    leisCollapse(container, "Typography",typo.map(function(item){
    
        const elem = setInput(item)
        typographyProp.setBtn(elem.input)
        StyleEmitter.handle(item.replace("-", ""), function(e, value){
            elem.input._conf.value = value
        })

        elem.input.addEvent("click", function(){
            configProp.propEmitter.invoke("typography")
        })
        return elem.container

        
    }))

    //spacing

    leisCollapse(container, "Spacing",["padding", "margin"].map(function(item){
    
        const elem = setInput(item)
            SpacingProp.setBtn(elem.input)
            StyleEmitter.handle(item.replace("-", ""), function(e, value){
                elem.input._conf.value = value
            })
    
            elem.input.addEvent("click", function(){
                configProp.propEmitter.invoke("spacing")
            })
            return elem.container

        
    }))

    //border
    leisCollapse(container, "Border",["border", "border-radius"].map(function(item){
    
        const elem = setInput(item)
        
            BorderProp.setBtn(elem.input)
            StyleEmitter.handle(item.replace("-", ""), function(e, value){
                elem.input._conf.value = value
            })
    
            elem.input.addEvent("click", function(){
                configProp.propEmitter.invoke("border")
            })
            return elem.container

        
    }))




    function setInput(lbl){
        const elem = textBox(null, lbl)
        elem.container.setStyleSheet({flexDirection : "row", justifyContent : "space-between"})
        elem.input.setStyleSheet({width : "50%"})
        .addAttr("readonly", "true")
        elem.label.setStyleSheet({fontSize : "15px"})

        return elem
    }
    return {
        container

    }
})()

export {StyleView}