import { leistrap } from "../leistrap/leistrap.js"
import { _EventEmitter } from "../obj/eventEmitter.js"
import { copyObject, has, loopObject, objKeysToLowerCase } from "../obj/index.js"
import { StylePropComponentEmitter } from "./eventCompStyle.js"
import { ColorProp } from "./props/color.js"
import { SizeProp } from "./props/size.js"
import { StyleEmitter } from "./eventCompStyle.js"
import { typographyProp } from "./props/typography.js"
import { SpacingProp } from "./props/spacing.js"
import { BorderProp } from "./props/border.js"



export const  configProp = (function(){

    const propEmitter = _EventEmitter()
  

    //color 
    propEmitter.handle('color', function(event){
        ColorProp.action = function(color){
            leistrap.currentElement.setStyleSheet({color})
            StyleEmitter.invoke("color",null,  color)
            leistrap.currentElement.styleData.color = color
        }
    })
    


    //backgroundColor
    propEmitter.handle('backgroundColor', function(event){
        ColorProp.action = function(color){
            leistrap.currentElement.setStyleSheet({backgroundColor : color})
            StyleEmitter.invoke("backgroundcolor",null,  color)
            leistrap.currentElement.styleData.backgroundcolor = color
        }
    })
  

    //size
    propEmitter.handle("size", function(e){
        SizeProp.action = function({style}){
            leistrap.currentElement.setStyleSheet(style)
        }
    })
    


    //typography
    propEmitter.handle("typography", function(e){
       typographyProp.action = function({style}){
        leistrap.currentElement.setStyleSheet(style)
       }
    })


    //spacing
    propEmitter.handle("spacing", function(e){
        SpacingProp.action = function({style}){
         leistrap.currentElement.setStyleSheet(style)
      
        }
     })
    
     
    
        //border
    propEmitter.handle("border", function(e){
        BorderProp.action = function(style){
         leistrap.currentElement.setStyleSheet(style)
        // console.log(style);
        
        }
     })
  
    

    //handles when the currentElement is changed
    StyleEmitter.handle("elementChanged", function(e, elem){
        
        //get styleData 
        if(!elem.styleData){
            let cp =  copyObject(window.getComputedStyle(elem._conf))
            cp = objKeysToLowerCase(cp)
            elem.styleData = cp
        }

        const styleData = elem.styleData



        //call styleEmitter
        loopObject(styleData, function(value, key){
            key = key.replace("-", "").toLowerCase()

            if(has(key, configProp.StyleEmitter.eventsList())){
                configProp.StyleEmitter.invoke(key, null, value)
            }

            if(has(key, StylePropComponentEmitter.eventsList())){
                StylePropComponentEmitter.invoke(key, null, value)
            }

        })

        
    })  
    
    //set all shortcuts
    const ALL_STYLE_COMP = 
    [ColorProp,
    ColorProp,
     ]

    setShortCuts(function(win){
        set_(win,"s+c", "color", ColorProp, function(){leistrap.event.invoke("colors:color")} )
        set_(win,"s+b", "backgroundColor", ColorProp, function(){leistrap.event.invoke("colors:bg")} )
        set_(win,"s+i", "size", SizeProp )
        set_(win,"s+t", "typography", typographyProp )
        set_(win,"s+p", "spacing", SpacingProp )
        set_(win,"s+o", "border", BorderProp )

    })

    function set_(win, sh, compCh, comp, listener){
        win.bind(sh, function(){
             leistrap.event.invoke("hidepopup", null, comp.pop.key)
            propEmitter.invoke(compCh)
            comp.show()
            if(listener) listener()
        })
    }
   
    // config all shortcuts to parentWInd (main window) and workspace (iframe)
    // setShortCuts()
    function setShortCuts(listener){
        leistrap.event.invoke("workspaceReady", null, function(workSpace){
            let WINDOWS = [workSpace._conf.contentDocument, window]
            WINDOWS.forEach(function(win){
             listener(win)
            })
            
        })
    }
    return {
        propEmitter,
        StyleEmitter
    }



})()