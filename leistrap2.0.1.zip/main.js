import { leistrap } from "./leistrap/leistrap.js";
import { APP } from "./leistrap_ui/index.js";

import { Root } from "./leistrap_ui/root.js";
import { StyleView } from "./leistrap_ui/style.js";

// import { FolderApp } from "./folderApp/index.js";

leistrap.whenReady(function(){
  APP()
  this.add(Root.container)
  StyleView


  // FolderApp(this)
})

leistrap.render("main")