
import { leistrap } from "../leistrap/leistrap.js";
import { _EventEmitter } from "../obj/eventEmitter.js";
import { copyObject, has, loopObject } from "../obj/index.js";

/**
 * 
 * @param {leistrap.Leistrap<HTMLIFrameElement>} workSpace_ 
 */
export function addElement(workSpace_){

    const FILE = {}

    const htmlTags = [
        "a", "abbr", "address", "area", "article", "aside", "audio", "b", "base", 
        "bdi", "bdo", "blockquote", "body", "br", "button", "canvas", "caption", 
        "cite", "code", "col", "colgroup", "data", "datalist", "dd", "del", "details", 
        "dfn", "dialog", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", 
        "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", 
        "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", 
        "kbd", "label", "legend", "li", "link", "main", "map", "mark", "meta", 
        "meter", "nav", "noscript", "object", "ol", "optgroup", "option", "output", 
        "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", 
        "script", "section", "select", "small", "source", "span", "strong", "style", 
        "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", 
        "tfoot", "th", "thead", "time", "title", "tr", "track", "u", "ul", "var", 
        "video", "wbr"
      ];


      // add a new element to leistrap.currentElement
      leistrap.event.handle('addElement', function(event, tagName){

        console.log(leistrap.currentElement);
        
      })



    leistrap.event.handle("elementShortcut", function(e, win){
       
        win.bind("e+n", function(){
           const tag =  prompt('create a new element')
           addNewElement(tag)
         })
        
        
    })

    function addNewElement(tagName){
        const parentElement = leistrap.currentElement
        const newElement = leistrap.create(tagName, {
            parent: parentElement, 
            text: "New element "+ tagName })
        
        FILE[newElement.key]= {
            key : newElement.key,
            parentKey : parentElement.key,
            text :   "New element "+ tagName,
            tag : tagName,
            style : {},
            attributes : {}
        }
    }

    leistrap.event.handle("FILE:content", function(event){
        event.send(JSON.stringify(FILE))
    })


    leistrap.event.handle("FILE:init-style", function(e, key){
        if(has(key, FILE))
            e.send(FILE[key].style)
        else(e.send({}))
    })

    leistrap.event.handle("FILE:prop-style", function(ev,key, style){
        copyObject(style, FILE[key].style, true)
        
        
    })

    leistrap.event.handle("FILE:init", function(e, data){

        let event = _EventEmitter()
        let DATA = JSON.parse(data)
        let elements = []
        loopObject(DATA, function(value, key){
            const elem = leistrap.create(value.tag, {
                text : value.text,
                style : value.style
            })
            elem.addAttr(value.attributes || {})
            
            elem.parentKey = value.parentKey
            elem.key = value.key
            value.key = elem.key
            elements.push(elem)
          

            event.handle(value.key, function(e, child){
                elem.add(child)
            })

           
            FILE[elem.key] = value
        })

        elements.forEach(function(item, index){

            if(item.parentKey == "body") 
                leistrap.event.invoke("body", null, item)

            event.invoke(item.parentKey, null, item).then(function(re){
                if(index == elements.length - 1){
                    elements = null
                    event = null
                }
            })
        })
    })
}