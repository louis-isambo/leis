import { leistrap } from "../leistrap/leistrap.js"
import { _EventEmitter } from "../obj/eventEmitter.js"
import { copyObject, has, loopObject, objKeysToLowerCase } from "../obj/index.js"
import { StylePropComponentEmitter } from "./eventCompStyle.js"
import { ColorProp } from "./props/color.js"
import { SizeProp } from "./props/size.js"
import { StyleEmitter } from "./eventCompStyle.js"
import { typographyProp } from "./props/typography.js"
import { SpacingProp } from "./props/spacing.js"
import { BorderProp } from "./props/border.js"
import { LayoutProp } from "./props/layout.js"


/**
 * this file contains all configurations of all styling components
 * ths  `propEmitter` event emitter contains all event channels of the styling components
 * to triggle or call a given component e.i color for color prop you have to use the interface 
 * @example 
 *  propEmitter.invoke("color")
 * 
 * NOte : the `propEmitter.invoke`, this method invoke the color picker component an d then 
 * displays this one into the page where a user can drag over the color hue to select a specific color
 * and update the `color` prop of the `leistrap.currentElement`.
 * 
 * 1. the leistrap.currentElement` is a global prop of the leistrap object that contains the current focused or 
 * just clicked element.
 * all component respect this structure.
 * 
 */
export const  configProp = (function(){


    /**
     * the eventEmitter for all components. each component will listen to a specific event channel
     * via `propEmitter.handel` method and the waiting for a an event invoke or emit  to display the
     * component  into the page where  a use easily use and update a specific CSS prop of the 
     * `leistrap.currentElement`.
     */
    const propEmitter = _EventEmitter()
  

    /**
     * this event channel `color` listen for an invoke of `color` (eventEmitter.invoke("color")) to 
     * display th color picker component (ColorProp).
     * 
     * Note : `ColorProp` is a component which contains the colorPicker hue and listen to the user 
     * dragging event into the spectra via the `ColorProp.action ` method then update  the color CSS prop  of 
     * the `leistrap.currentElement`
     * 
     * all below component or propEmitter.handle event respect this structure
     */
    propEmitter.handle('color', function(event){
        ColorProp.action = function(color){
            leistrap.currentElement.setStyleSheet({color})
            StyleEmitter.invoke("color",null,  color)
            leistrap.currentElement.styleData.color = color

            setFILE_Prop({color})
           
        }
    })
    


    //backgroundColor via the   ColorProp component
    propEmitter.handle('backgroundColor', function(event){
        ColorProp.action = function(color){
            leistrap.currentElement.setStyleSheet({backgroundColor : color})
            StyleEmitter.invoke("backgroundcolor",null,  color)
            leistrap.currentElement.styleData.backgroundcolor = color

            setFILE_Prop({backgroundColor : color})
        }
    })
  

    /**
     * ths Size event channel can change the leistrap.current
     */
    propEmitter.handle("size", function(e){
        SizeProp.action = function({style}){
            leistrap.currentElement.setStyleSheet(style)

            setFILE_Prop(style)
        }
    })
    


    //typography
    propEmitter.handle("typography", function(e){
       typographyProp.action = function({style}){
        leistrap.currentElement.setStyleSheet(style)

        setFILE_Prop(style)
       }
    })


    //spacing
    propEmitter.handle("spacing", function(e){
        SpacingProp.action = function({style}){
         leistrap.currentElement.setStyleSheet(style)

         setFILE_Prop(style)
      
        }
     })
    
     
    
        //border
    propEmitter.handle("border", function(e){
        BorderProp.action = function(style){
         leistrap.currentElement.setStyleSheet(style)
        
         setFILE_Prop(style)
        
        }
     })
  
    
     //layout
    propEmitter.handle("layout", function(e){
        LayoutProp.action = function(style){
         leistrap.currentElement.setStyleSheet(style)

         setFILE_Prop(style)
        }
     })

    //handles when the currentElement is changed
   
    StyleEmitter.handle("elementChanged", function(e, elem){
        
        //get styleData 
        if(!elem.styleData){
            let cp =  copyObject(window.getComputedStyle(elem._conf))
            elem.styleData = cp
            
            leistrap.event.invoke("FILE:init-style", function(style){
    
                copyObject(objKeysToLowerCase(style), elem.styleData, true)
                invokeAllStyleEmitter(style)
                
            }, elem.key)
           
            
        }

        const styleData = elem.styleData

        

        //call styleEmitter
        invokeAllStyleEmitter(styleData)
        function invokeAllStyleEmitter(style){
            loopObject(style, function(value, key){
                key = key.replace("-", "").toLowerCase()
    
                if(has(key, configProp.StyleEmitter.eventsList())){
                    configProp.StyleEmitter.invoke(key, null, value)
            
                    
                }
    
                if(has(key, StylePropComponentEmitter.eventsList())){
                    StylePropComponentEmitter.invoke(key, null, value)
                }
    
            })
        }

        
    })  
    
    //set all shortcuts
    const ALL_STYLE_COMP = 
    [ColorProp,
    ColorProp,
     ]

    setShortCuts(function(win){
        set_(win,"s+c", "color", ColorProp, function(){leistrap.event.invoke("colors:color")} )
        set_(win,"s+b", "backgroundColor", ColorProp, function(){leistrap.event.invoke("colors:bg")} )
        set_(win,"s+i", "size", SizeProp )
        set_(win,"s+t", "typography", typographyProp )
        set_(win,"s+p", "spacing", SpacingProp )
        set_(win,"s+o", "border", BorderProp )
        set_(win,"s+l", "layout", LayoutProp )
        leistrap.event.invoke("elementShortcut", null, win)

    })

    function set_(win, sh, compCh, comp, listener){
        win.bind(sh, function(){
             leistrap.event.invoke("hidepopup", null, comp.pop.key)
            propEmitter.invoke(compCh)
            comp.show()
            if(listener) listener()
        })
    }
   
    // config all shortcuts to parentWInd (main window) and workspace (iframe)
    // setShortCuts()
    function setShortCuts(listener){
        leistrap.event.invoke("workspaceReady", null, function(workSpace){
            let WINDOWS = [workSpace._conf.contentDocument, window]
            WINDOWS.forEach(function(win){
             listener(win)
            })
            
        })
    }

    function setFILE_Prop(style){
       
            
        leistrap.event.invoke("FILE:prop-style",
            null,
            leistrap.currentElement.key,
            style
        )
    }
    return {
        propEmitter,
        StyleEmitter
    }



})()