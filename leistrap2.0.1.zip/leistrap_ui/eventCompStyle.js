import { _EventEmitter } from "../obj/eventEmitter.js";


export const StylePropComponentEmitter = _EventEmitter()
export   const StyleEmitter = _EventEmitter()