const ActionHistory = (function(){

    const prevAction = []
    const nextAction = []

    function add(_history){
        if(_history) prevAction.push(_history)
    }

    function configDrop(dropUp){
        let prev = dropUp.action

        dropUp.action = function(argv){
            dropUp.history = {listener : prev,   arg : argv}
            prev(argv)
 
            
          }
        
          
        dropUp.once("hide", function(){
            add(dropUp.history)
        })

        dropUp.once("show", function(){
            delete dropUp.history
        })
    }


    window.bind("ctrl+z", function(){
        nextAction.push(prevAction.pop())
        let {listener,  arg} = prevAction[prevAction.length - 1]
        listener(arg)
        console.log(prevAction);
        
        
    })

    window.bind("ctrl+y", function(){
        let {listener, arg} = nextAction.pop()
        listener(arg)
        prevAction.push({listener, arg})
    })
    return {
        add,
        configDrop
    }


  
})()
export {ActionHistory}