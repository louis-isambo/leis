import { leistrap } from "../../leistrap/leistrap.js";
import { leisTab } from "../../tabPage/tabPage.js";
import { DropUp } from "../../popup/index.js";
import { btnRadio, textBox } from "../../input/leisInput.js";

import { _EventEmitter } from "../../obj/eventEmitter.js";
import { StyleEmitter } from "../eventCompStyle.js";
import { autoComplete } from "../../autocomplete/autocomplete.js";

export const LayoutProp = (function(){

    const event = _EventEmitter()
    const layoutCard = DropUp()
    layoutCard.pop.setStyleSheet({
        width  : "310px",
        height : "250"
      })

    layoutCard.once("show", function(){
        if(leistrap.currentElement){
            const ev = leistrap.currentElement.styleData.display || ""
            event.invoke(ev.toLocaleLowerCase().replaceAll("-", ""))

        }
    })
    leistrap.create("h3", {
        text: "Layout",
        parent: layoutCard.pop,
        className: 'pop-title'
    })
    const Header = leistrap.create("div", {className: "pop-header font-header", parent : layoutCard.pop,
        style : {marginBottom : "1rem"}
    })
    const body = leistrap.create("div", {parent : layoutCard.pop, className : "pop-body font-body"})

    const tab = leisTab({
        btnParent : Header,
        contentParent : body
    })

    const staticLayout = ["block", "none", "inline", "inline-block", "table"]
    const staticKLayoutContainer = leistrap.create("div", 
        {
            className : "leis-autoComplete",
        }
    )
    const listSTLO = leistrap.create("ul", {
        className : "lis-autoListItem",
        parent : staticKLayoutContainer,
        style : {border : "none"}
    })

    staticLayout.forEach(function(item){

        const RDB = btnRadio(null, item, function(){
            getStyle("display", item)
            StyleEmitter.invoke("display", null, item)
        })

        event.handle(item.toLocaleLowerCase().replaceAll("-", ""), function(){
            RDB.input._conf.click()
        })

        RDB.container.setStyleSheet({
            justifyContent: 'space-between',
            width : "100%",
            flexDirection : "row-reverse"
        }).setClassName("leis-flex leis-row")
        

        RDB.input.addAttr("name", "st-name")

        const LI = leistrap.create("li", {
            className : "autoItem",
            parent : listSTLO,
            content : [RDB.container]
        })
    })
    tab.define('static-layout', staticKLayoutContainer, {
        buttonText : "Display",
        createButton : true
    } ).setClassName("tab-btn-font")

    
    const flexValues = [
        "direction", "wrap", "gap",

    ]
    const FLVV = [
        ["column", "column-reverse", "row", "row-reverse", "inherit", "initial", "unset"],
        ["nowrap", "wrap", "wrap-reverse", "inherit", "initial", "unset"],
        ["10px", "16px", "0.5rem", "1rem"],
  
    ]
    const flexContainer = leistrap.create("div")

    flexValues.forEach(function(item, index){
        const elem = textBox(flexContainer, item)
        elem.input.setStyleSheet({width : "60%"})
        elem.container.setStyleSheet({flexDirection : "row"})
        elem.label.setStyleSheet({
            display: "inline-block",
            minWidth : "70px",
            fontSize : "15px"
        })

        autoComplete(elem.container, elem.input, 
           FLVV[index],
            // function(value){getStyle("fontWeight", value)}, true
        ).setClassName("aut-fw")

    })
    tab.define('flex', flexContainer, {
        buttonText : "Flex Box",
        createButton : true
    } ).setClassName("tab-btn-font")


    const gridContainer = leistrap.create("div")

    tab.define('grid', gridContainer, {
        buttonText : "Grid Box",
        createButton : true
    } ).setClassName("tab-btn-font")


    function getStyle(prop, value){

        const style = {}
        style[prop] = value
        leistrap.currentElement.styleData[prop.toLowerCase()] = value
        if(layoutCard.action) layoutCard.action(style)
    }

    tab.invoke("static-layout")
    return layoutCard

})()