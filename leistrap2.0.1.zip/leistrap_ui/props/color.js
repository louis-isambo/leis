import { leistrap } from "../../leistrap/leistrap.js";
import { colorName } from '../../color/colorName.js'
import { DropUp } from "../../popup/index.js";
import { has, loopObject, maxArray } from "../../obj/index.js";
import colorCss from "../css/color.css"
import { setPopPosition } from "../../popup/popup.js";
import { ColorisPicker } from "../../color/coloris/index.js";
import {textBox} from "../../input/leisInput.js"
import {leisTab} from "../../tabPage/tabPage.js"
import {leisButton} from "../../button/leisButton.js"
import { _EventEmitter } from "../../obj/eventEmitter.js";

leistrap.addCss(colorCss)
leistrap.addCss(leisButton())

export const ColorProp = (function () {

    let  prevColorName = null
    let prevCOlorValue  = "red"
    const colorEvent = _EventEmitter()
    
    ColorisPicker(function (color) {
        listeners.forEach(item => item(color))
    })
    const listeners = [
        (color, name) => {
            colorView.setStyleSheet({ backgroundColor: color })
            if (name) {
                leistrap.get("colorValueView", "setText", `${color}  (${name})`)
                // saveColorBtn.addAttr("disabled", "true")
            }

            else { 
                leistrap.get("colorValueView", "setText", `${color}`) 
                saveColorBtn.value = color
                // saveColorBtn.removeAttr("disabled")
            }
            if (colorMap.action) colorMap.action(color, name)
        }]

    const colorMap = DropUp()

    const previousColor = setColorBtn(prevCOlorValue, prevColorName)
    previousColor.content[0].removeEvent("click", "clr")
    previousColor.content[0].removeEvent("click", "ch")

    previousColor.content[0].addEvent("click", function(){
        listeners.forEach(item => item(prevCOlorValue, prevColorName))
        crlInput.value = prevCOlorValue
    })
    leistrap.event.handle("clr-previous:set", function(e, clrV, clrN){
        prevCOlorValue = clrV
        prevColorName  = clrN
        previousColor.content[0].setStyleSheet({backgroundColor : clrV})
    })

   const title =  leistrap.create("h3", {text : "Color",parent: colorMap.pop, 
        className : "pop-title leis-flex leis-row"})
    title.add(previousColor).setStyleSheet({paddingBottom : "0"})

    const Header = leistrap.create("div", {className: "pop-header font-header", parent : colorMap.pop})
    const body = leistrap.create("div", {parent : colorMap.pop, className : "pop-body font-body"})
    

    const SearchBar = textBox(Header)
    SearchBar.input.addAttr("placeholder", "Type color name, hex, rgb...")
    SearchBar.input.addEvent("keydown", function(e){
       if( e.keyCode == 13){
            let value = this._conf.value.toLowerCase().trim()

            if(value.startsWith("rgb")){
                const cv = setColorBtn(value)
                cv.content[0]._conf.click()
            }
            else if (value.startsWith("#")){
                const cv = setColorBtn(value)
                cv.content[0]._conf.click()
                // cv.destroy()
            }
            else if (value.startsWith("hsl")){
                const cv = setColorBtn(value)
                cv.content[0]._conf.click()
            }
            else{
                if(has(value, colorEvent.eventsList())){
                    colorEvent.invoke(value)
                }
            }
       }
    })
    
    const tab = leisTab({
        btnParent : Header,
        contentParent : body
    })

    const defaultColor = leistrap.create("div")
    const mayColor = leistrap.create('div', {
        parent: defaultColor,
        className: "col-6",
        style: { columnCount: 6 }

    })

    tab.define('defaultColor', defaultColor, {
        buttonText : "Default color",
        createButton : true
    } ).setClassName("tab-btn-font")

    tab.invoke("defaultColor")
    
    tab.define('myColor', mayColor, {
        buttonText : "My colors",
        createButton : true
    } ).setClassName("tab-btn-font")
    colorMap.pop.setStyleSheet({
        width: "315px"
    })

    // display color by names
    const colorNameContent = []
    loopObject(colorName, function (value, name) {

        let colorValue = `rgb(${value.join(",")})`
        colorNameContent.push(setColorBtn(colorValue, name.toLowerCase()))
    })

    const colorViewDialog = DropUp(colorMap.pop, ["right", "left", 'bottom', 'top'])
    const colorView = leistrap.create("div", {
        parent: colorViewDialog.pop,
        className: "colorView",
    })


    // color value vew
    leistrap.create("p", {
        data: { id: 'colorValueView' },
        parent: colorViewDialog.pop,
        className: "colorValueView",
    })

    // save color
    const saveColorBtn = leistrap.create("button", {
        text : "Save color",
        className : "leis-btn leis-outline-btn-success",
        parent : colorViewDialog.pop,
        onclick : function(e){
            e.stopImmediatePropagation()
          mayColor.add( setColorBtn(this.value))
        }
    }).setStyleSheet({width : "100%"})
    colorViewDialog.pop.setStyleSheet({
        width: "200px",
        height: "150px",
        padding: "10px",
    })

    // color picker Dialog
    let initColorPicker = false
    const crlInput = document.querySelector(".color-picker")
    crlInput.addEventListener("click", function (e) {
        e.target.exc = [colorViewDialog.pop.key, colorMap.pop.key]
    })

    colorViewDialog.pop.addEvent("click", function (e) {
        
        const clrPicker = document.getElementById("clr-picker")
        clrPicker.leisColor = "true"
        if (!initColorPicker) {
            clrPicker.addEventListener("click", function (e) {
                e.target.exc = [colorViewDialog.pop.key, colorMap.pop.key]
            })
        }
        setPopPosition("absolute", {
            container: colorViewDialog.pop._conf,
            popUp: crlInput,
            popUpRect: clrPicker.getClientRects()[0],
            side: ["top", "bottom", 'fight', 'left']
        })
        crlInput.click()

    })

    const colorByName = leistrap.create("div",
        {
            parent: defaultColor,
            content: colorNameContent,
            className: "col-6",
            style: { columnCount: 6 }

        })

    colorMap.onChange = (listener) => { listeners.push(listener) }
    
    function setColorBtn(colorValue, colorName){

        const button = leistrap.create("button",
            {
                type: "button",
                style: { background: colorValue },
                className: 'color-btn',
                onclick$clr: () => listeners.forEach(item => item(colorValue, name)),
                onclick$ch: () => crlInput.value = colorValue
            })
        
        if(colorName){
            colorEvent.handle(colorName, function(){
                button._conf.click()
            })
        }
        return leistrap.create("div",
            { content: [button], className: "leis-flex color-btn-cd" })
    }

    colorMap.once('hide', function(){
        colorMap.action = colorMap.prevAction || colorMap.action
        colorMap.children.forEach(function(item){item.hide()})
    })
    colorMap.children.push(colorViewDialog)
    return colorMap
})()