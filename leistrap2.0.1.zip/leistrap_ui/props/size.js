import { leistrap } from "../../leistrap/leistrap.js";
import { DropUp } from "../../popup/index.js";
import sizeCss from "../css/size.css"
import { textBox } from "../../input/leisInput.js"
import { has, loopObject, splitData } from "../../obj/index.js";
import { CssUnit } from "./unit.js";
import { StylePropComponentEmitter } from "../eventCompStyle.js";
import { StyleEmitter } from "../eventCompStyle.js";

leistrap.addCss(sizeCss)


const SizeProp = (function () {

    const sizeUnitChooser = CssUnit()
    sizeUnitChooser.useShow()
    //declaration of width, height, min-width, mib-heigh inputs

    const inputs = [
        { lbl: "width", lbl_r: "W", name: "width" },
        { lbl: "height", lbl_r: "H", name: "height" },
        { lbl: "min-width", lbl_r: "MNW", name: "minWidth" },
        { lbl: "min-height", lbl_r: "MNH", name: "minHeight" },
        { lbl: "max-width", lbl_r: "MXW", name: "maxWidth" },
        { lbl: "max-height", lbl_r: "MXH", name: "maxHeight" },
    ]

    function addInput(parent, lbl, name) {
        const item = textBox(parent, lbl)

        item.input.setStyleSheet({
            width: ' 40%'
        }).addAttr("type", "number")
            .addEvent("input", function () {
                getStyle(name, this._conf.value, unitBtn.getText())

                leistrap.currentElement.styleData[name.toLocaleLowerCase()] = 
                this._conf.value +unitBtn.getText()
        
                StyleEmitter.invoke(name.toLowerCase(), null,
                this._conf.value +unitBtn.getText() )

            }).addAttr("disabled", "true")

        item.container.setStyleSheet('flex-direction:  row; align-content: center')

        // add sia unit chooser
        const unitBtn = sizeUnitChooser.btn(item.container, item.input, function(unit){
            getStyle(name, item.input._conf.value, unit)
            leistrap.currentElement.styleData[name.toLocaleLowerCase()] = 
            item.input._conf.value  + unit
            
            StyleEmitter.invoke(name.toLowerCase(), null,
           item.input._conf.value +unit  )
        })

        //handles currentElement changed event

        StylePropComponentEmitter.handle(name.toLowerCase(), function(e, value){
           
            if(value.startsWith("calc")){
                sizeUnitChooser.setUnit("calc()", item.input)
                item.input.addAttr("disabled", "true")
                item.input._conf.value = ""
                unitBtn.setText("calc()")
            }
               
            else{        
                item.input._conf.value = parseFloat(value)
                let Vc = value.replace(/[\d]/g, "")
                if(Vc == "none"){
                    Vc = "auto"
                    item.input.addAttr("disabled", "true")
                }
                sizeUnitChooser.setUnit(Vc, item.input, unitBtn)
            }
        
        })
    }


    // size container pop up
    const sizeCard = DropUp()
    sizeCard.pop.setClassName("sizeCard")

    leistrap.create("h3", {
        text: "Size",
        parent: sizeCard.pop,
        className: 'pop-title'
    })
    sizeCard.pop.setStyleSheet({
        height: "300px",
        width: " 460px"
    })
    sizeCard.pop.data.id = "sizeUnit-card"

    // listen to click  even of the  sieCard  for  hiding the unitChooser
    sizeCard.once("click", function () {
        sizeUnitChooser.hide()
        overflowDrop.hide()
        overflowValueDrop.hide()
        boxSizeValueDrop.hide()
    })
    sizeCard.once("show", function () {
      if(overflowDrop.selected) overflowDrop.selected._conf.click()
    })


    function getStyle(_prop, value, unit) {
        //  call the  sizeCard action
        let prop = {
            prop: _prop,
            value,
            unit
        }
    
        if ( has( prop.unit, sizeUnitChooser.defaultUnit)) {
            prop.style = {}
            prop.style[prop.prop] = unit
        }
        else {
    
            prop.style = {}
            prop.style[prop.prop] = prop.value + prop.unit
        }
        
        if (sizeCard.action) sizeCard.action(prop)
    }

    function getStyleOverflow(prop, value) {
        let cp = prop.toLowerCase().split("-")
        prop = cp[0]
        if (cp.length == 2) prop = cp[0] + cp[1].toUpperCase()

        let propStyle = {
            prop,
            value: value.toLocaleLowerCase(),
            style: {}
        }
        propStyle.style[prop] = propStyle.value
        leistrap.currentElement.styleData[prop.toLowerCase()] = value
  
        
        
        if (sizeCard.action) sizeCard.action(propStyle)
    }

    function getStyleBoxSizing(value) {
        let prop = {
            prop: "boxSizing",
            value,
            style: { boxSizing: value }
        }

        leistrap.currentElement.styleData.boxsizing = value
        if (sizeCard.action) sizeCard.action(prop)

    }
    // finally  display all inputs
    splitData(inputs, 2).reverse().forEach(item => {

        const inputParent = leistrap.create("div", {
            parent: sizeCard.pop,
            className: "leis-flex leis-row size-input-cd",
        })
        item.forEach(input => addInput(inputParent, input.lbl, input.name))


    })

    // overflow 
    const overflow = ["visible", "hidden", "auto", "scroll", "initial", "inherit", "unset"]

    const overflowBtn = leistrap.create('button', {
        className: "size-over-btn",
        text: "overflow"
    })
    const overflowValue = leistrap.create('button', {
        className: "size-over-btn",
        text: "visible"
    })

    const overflowDrop = DropUp(overflowBtn)
    overflowDrop.pop.setStyleSheet({
        width: "200px",
        height: "100px"
    }).addElements(...["Overflow", "Overflow-X", "Overflow-Y"].map(item =>
        leistrap.create("div", {
            text: item,
            className: "overflow-item",
            onclick: function () {
                if (overflowDrop.selected)
                    overflowDrop.selected.removeClassName("selected")
                overflowDrop.data = item
                const valueOverflow =  leistrap.currentElement.styleData[item.toLowerCase().replace("-", "")]
                getStyleOverflow(overflowDrop.data, valueOverflow)
                this.setClassName("selected")
                overflowBtn.setText(item)
                overflowDrop.selected = this
                overflowValueDrop.pop.content.forEach(function(itemJ){
                    itemJ.removeClassName("selected")
                    if(itemJ.getText() == valueOverflow ){
                        itemJ.setClassName("selected")
                        overflowValueDrop.selected = itemJ
                        itemJ._conf.click()
                    }
                })
                
                
    
            }
        }))).setStyleSheet({ padding: "0" })

    const overflowValueDrop = DropUp(overflowValue)
    overflowValueDrop.pop.setStyleSheet({
        width: "200px",
        height: "230px"
    }).setStyleSheet({ padding: "0" }).addElements(...overflow.map(item => leistrap.create("div", {
        text: item,
        className: "overflow-item",
        onclick: function () {
            if (overflowValueDrop.selected)
                overflowValueDrop.selected.removeClassName("selected")
            overflowValueDrop.data = item
            getStyleOverflow(overflowDrop.data, overflowValueDrop.data)
            this.setClassName("selected")
            overflowValue.setText(item)
            overflowValueDrop.selected = this
        }
    })))

    leistrap.create("div", {
        parent: sizeCard.pop,
        className: "leis-flex leis-row size-input-cd overflow",
        content: [overflowBtn, overflowValue]
    })

    //initial the overflow data
    overflowValueDrop.data = "visible",
    overflowDrop.data = "overflow"

    //box-sizing
    const boxSizing = ["border-box", 'content-box', "inherit", 'initial', "unset"]
    const boxSizeBtn = leistrap.create('button', {
        className: "size-over-btn",
        text: "Box-sizing"
    })
    const boxSizeValue = leistrap.create('button', {
        className: "size-over-btn",
        text: "content-box"
    })

    const boxSizeValueDrop = DropUp(boxSizeValue)
    boxSizeValueDrop.pop.setStyleSheet({
        width: "200px",
        height: "200px"
    }).setStyleSheet({ padding: "0" }).addElements(...boxSizing.map(item => leistrap.create("div", {
        text: item,
        className: "overflow-item",
        onclick: function () {
            if (boxSizeValueDrop.selected)
                boxSizeValueDrop.selected.removeClassName("selected")
            boxSizeValueDrop.data = item
            getStyleBoxSizing(boxSizeValueDrop.data)
            this.setClassName("selected")
            boxSizeValue.setText(item)
            boxSizeValueDrop.selected = this
        }
    })))

    leistrap.create("div", {
        parent: sizeCard.pop,
        className: "leis-flex leis-row size-input-cd overflow",
        content: [boxSizeBtn, boxSizeValue]
    })
    // init the default box-sizing value
    boxSizeValueDrop.data = "content-box"
    
    //listen to the currentElement changed event to get the boxSizing value

    StylePropComponentEmitter.handle("boxsizing", function(e, value){
       boxSizeValueDrop.pop.content.forEach(function(item){
        item.removeClassName("selected")
        if(item.getText() == value){
            // item.setClassName("selected")
            boxSizeValueDrop.selected = item
            item._conf.click()
        }
       })
        
    })
    return sizeCard
})()

export { SizeProp }