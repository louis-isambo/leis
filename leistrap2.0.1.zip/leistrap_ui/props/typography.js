import {DropUp} from "../../popup/index.js"
import {leistrap} from "../../leistrap/leistrap.js"
import {textBox} from "../../input/leisInput.js"
import { FontProp } from "./font.js"
import { autoComplete } from "../../autocomplete/autocomplete.js"
import { has, rangeList } from "../../obj/index.js"
import {CssUnit} from "./unit.js"
import typoCss from "../css/typography.css"
import { StyleEmitter, StylePropComponentEmitter } from "../eventCompStyle.js"


leistrap.addCss(typoCss)
const typographyProp = (function(){


    const typoCard = DropUp()
    typoCard.pop.setStyleSheet({
        width  : "310px",
        height : "250"
      })

    leistrap.create("h3", {
        text: "Typography",
        parent: typoCard.pop,
        className: 'pop-title'
    })

    const values = ["fontfamily", "fontweight", "fontsize", "fontstyle", "lineheight"]
    const fontFamily = textBox(typoCard.pop, "Font-Family")
    const fontWeight = textBox(typoCard.pop, "Font-Weight")
    const fontSize =  textBox(typoCard.pop, "Font-Size")
    const fontStyle = textBox(typoCard.pop, "Font-Style")
    const lineHeight = textBox(typoCard.pop, "Line-Height")

    const allInputs = [fontFamily, fontWeight, fontSize, fontStyle, lineHeight]
    allInputs.forEach(function(item, index){
        item.input.setStyleSheet({width : "60%"})
        item.container.setStyleSheet({flexDirection : "row"})
        item.label.setStyleSheet({
            display: "inline-block",
            minWidth : "70px",
            fontSize : "13px"
        })

      
        // get typography props of the currentElement and then update the typo
        // component's input values
    
      
        
        StylePropComponentEmitter.handle(values[index], function(event, value){
            item.input._conf.value = has(values[index], ["fontsize", "lineheight"]) ? parseFloat(value) : value
            
         
            if(values[index] == "fontsize"){            
                let unit = value.replace(/[0-9,-.]/g, "")      
                btnUnit.unit = unit
               sizeUnitChooser.setUnit(unit, item.input, btnUnit)
              
            }
          

        })
    })

    FontProp.setBtn(fontFamily.input)
    FontProp.once("show", function(){
        const prevAction = FontProp.action
        FontProp.action = function(style){
            fontFamily.input._conf.value = style.fontName
            if(prevAction) prevAction(style)
        }
       
    })

    autoComplete(fontWeight.container, fontWeight.input, 
        rangeList(1000, 0, 100).map(item=> new String(item)),
        function(value){getStyle("fontWeight", value)}, true
    ).setClassName("aut-fw")
    fontWeight.container.setClassName("fw")

    fontWeight.input.addAttr("type", "number")
    typoCard.once("click", function(){
        FontProp.hide()
        sizeUnitChooser.hide()
    })

    typoCard.once("show", function(){
       if(btnUnit.selected) {
        sizeUnitChooser.show()
        btnUnit.selected._conf.click()
        sizeUnitChooser.hide()

       }

    })
    fontWeight.input.addEvent("input", function () {getStyle("fontWeight", this._conf.value)})
    const sizeUnitChooser = CssUnit()

    /**
     * @type {leistrap.Leistrap<HTMLButtonElement>}
     */
    const btnUnit = sizeUnitChooser.btn(fontSize.container, fontSize.input,function(unit){
       getStyle("fontSize", fontSize.input._conf.value+unit)
        
    } )
    btnUnit.setClassName("fs-b")
    fontSize.input.addEvent("input", function(){
        getStyle("fontSize", this._conf.value+btnUnit.unit)
    }).addAttr("type", "number")
   

    autoComplete(fontStyle.container, fontStyle.input, 
       ["italic", "normal", "oblique", "inherit", "initial", "unset"].map(item=> new String(item)),
        function(value){getStyle("fontStyle", value)}, true
    ).setClassName("aut-fw")

    lineHeight.input.addAttr("type", "number")
    lineHeight.input.addEvent("input", function(){
        getStyle("lineHeight", this._conf.value)
    })

    FontProp.action = function({fontName}){
       getStyle("fontFamily", fontName)
     
        
    }
    function getStyle(prop , value){
       
        
        let style = {}
        style[prop]  = value
        leistrap.currentElement.styleData[prop.toLowerCase()] = value
      
        StyleEmitter.invoke(prop.toLowerCase(), null, value)
        if(typoCard.action) typoCard.action({style})
    }

    return typoCard
})()


export {typographyProp}