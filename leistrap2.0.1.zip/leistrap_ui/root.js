

import { leistrap } from "../leistrap/leistrap.js";
import rootCss from "./css/root.css"
import {shortCut} from "../obj/shortCut.js"


leistrap.addCss(rootCss)

const Root = (function(){
      
    const container = leistrap.create("div", {
        className : "leistrapUI-root"
    })

    const header = leistrap.create("div", {
        className : "leis-flex leis-row header",
        parent : container,

    })

    const sideFun = leistrap.create("div", {
        parent : container,
        className: "leis-flex sideFun"
    })


    const side = leistrap.create("div", {
        className : "side"
    })

    const content  = leistrap.create("div", {
        className : "content"
    })

    const propSide = leistrap.create("div", {
        className : "propSide"
    })

    const contentContainer = leistrap.create("div", {
        parent : container,
        content : [side, content, propSide],
        className : "contentContainer leis-flex leis-row"
    })

    const workSpace = leistrap.create("iframe", {
        className : "workSpace",
        parent : content,
    })

    
    let prop = {
        width : 60
    }
    
    shortCut(window)
    hideShow(side , "ctrl+b", window)
    hideShow(propSide , "ctrl+j", window)


    window.bind("ctrl+s", function(e){
        e.preventDefault()
        leistrap.event.invoke("FILE:save")
    })

    function hideShow(elem, sh, parentWindow){
        parentWindow.bind(sh, function(e){
            e.preventDefault()
            if(!elem.state.visible){ 
                prop.width -= 20
                elem.removeAttr("hidden")
                content.setStyleSheet({width : prop.width.toString()+"%"})
                elem.state.visible=  true
                
            }
            else{
                prop.width += 20
                elem.addAttr('hidden', "true")
                content.setStyleSheet({width : prop.width.toString()+"%"})
                elem.state.visible= false
            }
        
        })
    }
    const ROOT = {
        container, 
        header,
        sideFun,
        side,
        content,
        contentContainer,
        propSide,
        workSpace,
        whenReady : null
    }

    // wait for the workspace creation
    let checker = setInterval(function(){
        if(workSpace._conf.className){
          let body = workSpace._conf.contentDocument.body
          if(ROOT.whenReady) ROOT.whenReady(body)

            shortCut(Root.workSpace._conf.contentDocument)
            hideShow(side , "ctrl+b", Root.workSpace._conf.contentDocument)
            hideShow(propSide , "ctrl+j", Root.workSpace._conf.contentDocument)
            leistrap.event.handle("workspaceReady", function(e, listener){listener(workSpace)})
          clearInterval(checker)
          
        }
      }, 1000)
      
    return ROOT
})()


export {Root}