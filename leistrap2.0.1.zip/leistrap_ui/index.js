import { leistrap } from "../leistrap/leistrap.js";
import { rangeList } from "../obj/index.js";
import { configProp } from "./confugProp.js";
import { addElement } from "./element.js";
import { Root } from "./root.js";



function APP(){

    Root.whenReady = function(body){

        //  configure the adding element functionality
        addElement(Root.workSpace)
        
        let workSpaceBody = leistrap.create("div")
        workSpaceBody._conf = body
        workSpaceBody.key = "body"
        body.currentElement = workSpaceBody
    
        leistrap.currentElement = workSpaceBody
        workSpaceBody.styleData = {}

        leistrap.event.handle("body", function(e, elem){
            workSpaceBody.add(elem)
        })

        // add a style tag for loading google font
        let googleFont = leistrap.create("style", {parent : workSpaceBody})
        leistrap.event.handle("googleFontLoading", function(e, value){
            googleFont._conf.innerText += value
        })
        
        
        if(localStorage.getItem("content"))
            leistrap.event.invoke("FILE:init", null, localStorage.getItem("content"))
        leistrap.create("button", {
            text : "download", 
            parent : Root.header,
            onclick(){
                // console.log();
                // const bl = new Blob([Root.workSpace._conf.contentDocument.documentElement.innerHTML], {type: "text/html"})
                // const url = URL.createObjectURL(bl)
                // leistrap.create("a", {
                //     href: url, 
                //     download : "myFile.html",
                // })._conf.click()

                // URL.revokeObjectURL(url)

               leistrap.event.invoke("FILE:content", function(data){
                if(localStorage.getItem("content")){
                    localStorage.clear()
                }
                localStorage.setItem("content", data)
                
               })
                
            }   
        })
        
        //get all element by a click
        Root.workSpace._conf.contentDocument.addEventListener("click", function(e){
            leistrap.currentElement = e.target.currentElement

            //call styleEmitter to handle elementChanged event
            configProp.StyleEmitter.invoke("elementChanged", null, leistrap.currentElement)
                   
            leistrap.event.invoke("hidepopup")
            
            // close colorPicker
            leistrap.event.invoke("colorPicker:close")

            // set mainWin focus
            window.focus()
            
        })

    
        // listen to the cursor enter
        let prev
        let prevH
        Root.workSpace._conf.contentDocument.addEventListener("click", function(e){
            if(prev) {
                prev.setStyleSheet({
                    border : "none",
                })
            }
            if(e.target.currentElement){
                e.target.currentElement.setStyleSheet({
                    border : "1.5px solid blue"
                })
            }
            prev = e.target.currentElement
        })

        Root.workSpace._conf.contentDocument.addEventListener("mousemove", function(e){
            if(prevH) {
                prevH.setStyleSheet({
                    outline : "none",
                })
            }
            if(e.target.currentElement){
                e.target.currentElement.setStyleSheet({
                    outline : "1px solid red"
                })
            }
            prevH = e.target.currentElement
        })
    }
}

export {APP}