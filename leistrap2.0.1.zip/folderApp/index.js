
import {leistrap} from "../leistrap/leistrap.js"
import { Draggable } from "../mouseEvent/draggable.js"
import { Resizable } from "../mouseEvent/resizable.js"
import mainCss from "./css/main.css"

leistrap.addCss(mainCss)

export function FolderApp(parent){

    const container = leistrap.create("div", {text : "lorem"})
    const header = leistrap.create("div", {
        className : "folder-header",
        parent : container
    })
    const  side = leistrap.create('div', {
        className : "folder-side",
        parent : container
    })

   const element =  leistrap.create("button", {
        className : "box resize-box",
       
        parent : container,
        content : [leistrap.create("div", {className : "fx", text : leistrap.MLorem(2),})]
    })

    // Draggable(element._conf, {autoDragging : true})
    Resizable(element._conf, null)
    parent.add(container)

}